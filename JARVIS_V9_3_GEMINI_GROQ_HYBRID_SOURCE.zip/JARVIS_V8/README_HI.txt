JARVIS ULTIMATE V9 - PHASE 1 FOUNDATION

Project type: Native Android Java app source (not an APK).
Application ID: com.jarvis.personalassistant
Version: 9.0 (versionCode 9)

Implemented in this starter upgrade:
- Refreshed dark JARVIS command-center interface.
- Hindi speech input through Android SpeechRecognizer (requires a compatible installed recognition service; network may be needed).
- Deepened TTS profile using pitch 0.78 and speech rate 0.88. Actual sound depends on the installed TTS engine and voice.
- Persistent local note memory and last-response memory using SharedPreferences.
- Custom voice commands that can open a user-supplied HTTPS URL.
- Time/date, battery, RAM/app-heap and available-storage status.
- Supported shortcuts to Wi-Fi/Bluetooth/settings, camera app, YouTube, web search, Maps, Translate and alarm UI.
- Basic local mission-planning response template.

Not implemented yet (planned later phases; do not assume these work):
- Always-on "Hey JARVIS" keyword spotting.
- Background microphone foreground service and locked-screen wake-up.
- Lock-screen full-screen assistant UI.
- True speaker/voice identity verification.
- Notification listener and notification summarization.
- On-device LLM / advanced offline AI.
- Camera image understanding (current camera button only opens the camera app).
- Multi-agent execution, predictive simulation and tactical data analysis.
- Emergency SOS automation and automatic location sharing.

Important Android limits:
- Android restricts background microphone use and launching activities over the lock screen. These features need a dedicated, tested foreground-service/wake-word design and may be limited by device vendor battery policies.
- Voice pitch is a best-effort setting; installed TTS engines may ignore or limit it.
- Phone actions requiring protected permissions, accessibility, notification access, location, or user confirmation need separate opt-in setup.
- This project is an offline-first command foundation, not a full offline LLM or military system.

Build:
- Open the project root in Android Studio / compatible Gradle Android IDE.
- Use JDK 17 and Android Gradle Plugin 8.7.3 / Gradle 8.9.
- Compile SDK 35; min SDK 23; target SDK 28 (legacy target retained for compatibility; review target SDK before Play distribution).
- Build the debug APK with: gradle assembleDebug

Test on the target phone after installing. The source was updated, but no APK build was run in this environment because an Android Gradle build toolchain/SDK is not available here.


V9.2 HYBRID AI UPDATE
Offline LLM integration: LiteRT-LM (.litertlm model file required).
Online LLM integration: OpenAI-compatible endpoint + user API key required.
See HYBRID_AI_SETUP_HI.txt before configuring. No model or API key is bundled.


JARVIS V9.3 — GEMINI + GROQ HYBRID UPDATE

WHAT CHANGED
- Gemini is the primary online AI provider.
- Groq is tried automatically if Gemini returns an error or is unavailable.
- Provider model IDs are configurable in ONLINE AI SETUP.
- Default Gemini model: gemini-2.5-flash.
- Default Groq model: openai/gpt-oss-120b (check your current Groq console for access).
- API keys are encrypted at rest using an AES-GCM key held by Android Keystore.
- If both online providers fail and a compatible local model is loaded, JARVIS falls back to it.
- Saved note and previous assistant response are added as limited context to online prompts.

SETUP
1. Open ONLINE AI SETUP in JARVIS.
2. Create a Gemini API key at https://aistudio.google.com/ and paste it in Gemini API key.
3. Create a Groq API key at https://console.groq.com/ and paste it in Groq API key.
4. Keep the default model IDs initially; if a provider says model unavailable, choose an active model shown in that provider console.
5. Save. Ask a normal question to test Gemini. If Gemini is unavailable, Groq is attempted automatically.
6. Use CLEAR KEYS to remove stored provider credentials.

IMPORTANT SECURITY / LIMITS
- Keys are encrypted at rest on this device, but an APK that calls providers directly is not equivalent to a secure server-side proxy. A rooted/compromised device or runtime instrumentation can expose credentials. Do not share the APK with embedded personal keys.
- Gemini/Groq free quotas are controlled by each provider and may change. A free API is not the same as ChatGPT Plus and may rate-limit requests.
- Gemini free-tier data handling may differ from paid tier. Avoid sending sensitive personal information.
- The source has not been compiled in this environment because Gradle/Android SDK are unavailable here. Build with Android Studio or the included GitHub Actions workflow before installing.
- The offline model is not bundled. Always-on Hey JARVIS wake word and final HUD are not part of this AI provider integration.
